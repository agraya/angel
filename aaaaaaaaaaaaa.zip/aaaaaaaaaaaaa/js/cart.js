
let carray = []

function addcart(){

        for(let i = 0; i < length.carray; i++){
            i += 1;

        }
return i;
}

function removecart(){
      i -= 1;

}

function addarray(item){

}