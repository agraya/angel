
window.addEventListener("load", () => {

    const dd2 = document.getElementById("dhenkan");
    let i = 0;
    let u = 1;

    const koteiprice = document.querySelectorAll(".price");
    const aaa = []

for(data of koteiprice){
    aaa.push(data);
}


    /*const stringifiedprice = JSON.stringify(aaa);*/
    localStorage.setItem('firstprice', aaa);
    console.log(aaa)

    dd2.addEventListener("click", () => {

        if (i == 0) {
            i += 1;

            const dprice = localStorage.getItem('firstprice');
            const dprice2 = JSON.parse(dprice);
            console.log(dprice2)
            console.log(dprice)

            for (data of dprice2) {

                let result = 0;
                let afterprice = 0;
                afterprice = parseFloat(data.innerHTML);
                result = afterprice / 150;
                result = Math.round(result);
                data.innerHTML = result;
            }

            let endoru = document.querySelectorAll(".endoru");

            for(d of endoru){
            d.innerHTML = "$";
            }
            u -= 1;
        }


    })

    const dd1 = document.getElementById("yhenkan");

    dd1.addEventListener("click", () => {

        if (u == 0) {
            u += 1;

            let yprice = [...koteiprice]

            for(data of yprice){

            let result = 0;
            let afterprice = 0;
            afterprice = parseFloat(data.innerHTML);
            result = afterprice ;
            result = Math.round(result);
            data.innerHTML = result;

            }

            let endoru = document.querySelectorAll(".endoru");

            for(d of endoru){
            d.innerHTML = "¥";
            }

            i -= 1;
        }



    })
});
