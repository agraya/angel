
let dprice = document.querySelectorAll(".price");
let hikitugi = 0;
let hikitugiarr = [];


window.addEventListener("load", () => {

    const dd2 = document.getElementById("dhenkan");
    let i = 0;
    let u = 1;



    dd2.addEventListener("click", () => {

        if (i == 0) {
            i += 1;



            for (data of dprice) {

                let result = 0;
                let afterprice = 0;
                afterprice = parseFloat(data.innerHTML);
                result = afterprice / 153;
                hikitugi = afterprice / 153;
                hikitugiarr.push(hikitugi);
                result = Math.round(result);
                data.innerHTML = result;

            }

            let endoru = document.querySelectorAll(".endoru");

            for (d of endoru) {
                d.innerHTML = "$";
            }

            u -= 1;

        }


    })

    const dd1 = document.getElementById("yhenkan");

    dd1.addEventListener("click", () => {

        let resultarr = [];

        if (u == 0) {
            u += 1;
            console.log(hikitugiarr)

            for (data of hikitugiarr) {

                let result = 0;

                result = data * 153;
                resultarr.push(result);
                console.log(resultarr)



            }
            dprice = resultarr;
            for (data of dprice) {
                let y = 0;
                y += 1;
                document.querySelectorAll(".price").innerHTML = dprice[y];

            }

            let endoru = document.querySelectorAll(".endoru");

            for (d of endoru) {
                d.innerHTML = "¥";
            }


            i -= 1;
        }


    })
});
