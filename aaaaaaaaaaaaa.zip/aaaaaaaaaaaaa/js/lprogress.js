const progress = document.querySelector("#lprogress");
const progressResult = document.querySelector("#progressResult");



window.addEventListener("load", proc1());

function proc1()
{
	if (document.getElementById('lprogress').value < 100 ) {
		document.getElementById('lprogress').value++;
		setTimeout(proc1, 10);
	}
}