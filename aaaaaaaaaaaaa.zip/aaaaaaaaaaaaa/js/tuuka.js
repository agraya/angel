$(function () {
    $("#language dt").on("click", function () {
        $("#language dd").toggle();
        $(this).toggleClass("active");

    });


    $("#language dd").on("click", function () {
       var lan = $(this).text();
       $("#language dt").text(lan);
    });


});
