$(function () {
    function end_loader() {
        $('.loader2').fadeOut(800);
    }
    $("#yhenkan").on('click', function () {
        $('.loader2').fadeIn(0);
        setTimeout(function () {
            end_loader();
        }, 500)
    })


    $("#dhenkan").on('click', function () {
        $('.loader2').fadeIn(0);
        setTimeout(function () {
            end_loader();
        }, 500)
    })

})

