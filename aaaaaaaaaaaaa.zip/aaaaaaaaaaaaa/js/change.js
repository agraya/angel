
window.addEventListener("load", () => {

    const dd2 = document.getElementById("dhenkan");
    let i = 0;
    let u = 1;

    const koteiprice = document.querySelectorAll(".price");



    dd2.addEventListener("click", () => {

        if (i == 0) {
            i += 1;

            const dprice = koteiprice

            for (data of dprice) {

                let result = 0;
                let afterprice = 0;
                afterprice = parseFloat(data.innerHTML);
                result = afterprice / 100;
                result = Math.round(result);
                data.innerHTML = result;
            }

            let endoru = document.querySelectorAll(".endoru");

            for(d of endoru){
            d.innerHTML = "$";
            }
            u -= 1;
        }


    })

    const dd1 = document.getElementById("yhenkan");

    dd1.addEventListener("click", () => {

        if (u == 0) {
            u += 1;

            let yprice = koteiprice

            for(data of yprice){

            let result = 0;
            let afterprice = 0;
            afterprice = parseFloat(data.innerHTML);
            result = afterprice * 100;
            result = Math.round(result);
            data.innerHTML = result;

            }

            let endoru = document.querySelectorAll(".endoru");

            for(d of endoru){
            d.innerHTML = "¥";
            }

            i -= 1;
        }



    })
});
